if [ "$USER" != "root" -a "$(whoami 2>/dev/null)" != "root" ]; then
  echo "killpi: need root permissions";
  exit 1;
fi;

killall -v com.google.android.gms.unstable;
killall -v com.android.vending;
