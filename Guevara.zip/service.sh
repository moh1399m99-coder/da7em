MODPATH="${0%/*}"
. $MODPATH/common_func.sh

resetprop_if_match ro.boot.mode recovery unknown
resetprop_if_match ro.bootmode recovery unknown
resetprop_if_match vendor.boot.mode recovery unknown


resetprop_if_diff ro.boot.selinux enforcing

if ! $SKIPDELPROP; then
    delprop_if_exist ro.build.selinux
fi

if [ "$(toybox cat /sys/fs/selinux/enforce)" = "0" ]; then
    chmod 640 /sys/fs/selinux/enforce
    chmod 440 /sys/fs/selinux/policy
fi




{
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done


resetprop_if_diff ro.secureboot.lockstate locked

resetprop_if_diff ro.boot.flash.locked 1
resetprop_if_diff ro.boot.realme.lockstate 1

resetprop_if_diff ro.boot.vbmeta.device_state locked

resetprop_if_diff vendor.boot.verifiedbootstate green

resetprop_if_diff ro.boot.verifiedbootstate green
resetprop_if_diff ro.boot.veritymode enforcing
resetprop_if_diff vendor.boot.vbmeta.device_state locked


resetprop_if_diff sys.oem_unlock_allowed 0

}&
