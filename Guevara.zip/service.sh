MODPATH="${0%/*}"
. "$MODPATH"/common_func.sh

# Conditional sensitive properties

# Magisk Recovery Mode
$RESETPROP_if_match ro.boot.mode recovery unknown
$RESETPROP_if_match ro.bootmode recovery unknown
$RESETPROP_if_match vendor.boot.mode recovery unknown

# SELinux
$RESETPROP_if_diff ro.boot.selinux enforcing
# use toybox to protect stat access time reading
if [ "$(toybox cat /sys/fs/selinux/enforce)" = "0" ]; then
    chmod 640 /sys/fs/selinux/enforce
    chmod 440 /sys/fs/selinux/policy
fi

# Conditional late sensitive properties

until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done

# SafetyNet/Play Integrity + OEM
# avoid bootloop on some Xiaomi devices
$RESETPROP_if_diff ro.secureboot.lockstate locked
# avoid breaking Realme fingerprint scanners
$RESETPROP_if_diff ro.boot.flash.locked 1
$RESETPROP_if_diff ro.boot.realme.lockstate 1
# avoid breaking Oppo fingerprint scanners
$RESETPROP_if_diff ro.boot.vbmeta.device_state locked
# avoid breaking OnePlus display modes/fingerprint scanners
$RESETPROP_if_diff vendor.boot.verifiedbootstate green
# avoid breaking OnePlus/Oppo fingerprint scanners on OOS/ColorOS 12+
$RESETPROP_if_diff ro.boot.verifiedbootstate green
$RESETPROP_if_diff ro.boot.veritymode enforcing
$RESETPROP_if_diff vendor.boot.vbmeta.device_state locked

# Other
$RESETPROP_if_diff sys.oem_unlock_allowed 0
