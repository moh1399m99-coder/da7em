# Detect root environment
if [ -d /data/adb/magisk ]; then
    ROOT_ENV="Magisk"
elif [ -d /data/adb/kernelsu ]; then
    ROOT_ENV="KernelSU"
elif [ -d /apatch ]; then
    ROOT_ENV="APatch"
else
    ROOT_ENV="Unknown"
fi

echo "Detected root environment: $ROOT_ENV"
export ROOT_ENV
# Don't flash in recovery (safe for all roots)
if [ -z "$BOOTMODE" ] || [ "$BOOTMODE" = false ]; then
    ui_print "*********************************************************"
    ui_print "! Install from recovery is NOT supported"
    ui_print "! Recovery installs are skipped"
    ui_print "! Please use your root manager app"
    
fi

# Error on < Android 8
if [ "$API" -lt 26 ]; then
    abort "! You can't use this module on Android < 8.0"
fi

# safetynet-fix module is obsolete and it's incompatible with PIF
SNFix="/data/adb/modules/safetynet-fix"
if [ -d "$SNFix" ]; then
    ui_print "! safetynet-fix module is obsolete and it's incompatible with PIF, it will be removed on next reboot"
    ui_print "! Do not install it"
    touch "$SNFix"/remove
fi

# playcurl warn
if [ -d "/data/adb/modules/playcurl" ]; then
    ui_print "! playcurl may overwrite fingerprint with invalid one, be careful!"
fi

# MagiskHidePropsConf module is obsolete in Android 8+ but it shouldn't give issues
if [ -d "/data/adb/modules/MagiskHidePropsConf" ]; then
    ui_print "! WARNING, MagiskHidePropsConf module may cause issues with PIF."
fi
#Tricky Store
cp -f "$MODPATH/inject/keybox.xml" /data/adb/tricky_store/
cp -f "$MODPATH/inject/target.txt" /data/adb/tricky_store/
rm -f /data/adb/tricky_store/security_patch.txt
# Check custom fingerprint
if [ -f "/data/adb/pif.json" ]; then
    ui_print "- Backup custom pif.json"
    mv -f /data/adb/pif.json /data/adb/pif.json.old
fi

# give exec perm to action.sh
chmod +x "$MODPATH/action.sh"

