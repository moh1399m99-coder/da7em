MODPATH="${0%/*}"


set +o standalone
unset ASH_STANDALONE

sh $MODPATH/autopif2.sh -m || exit 1

echo -e "\nDone!"

if [ "$KSU" = "true" -o "$APATCH" = "true" ] && [ "$KSU_NEXT" != "true" ] && [ "$WKSU" != "true" ] && [ "$MMRL" != "true" ]; then
    echo -e "\nClosing dialog in 20 seconds ..."
    sleep 20
fi
