MODPATH="${0%/*}"
. $MODPATH/common_func.sh

if [ -d "$MODPATH/zygisk" ]; then
    
    if magisk --denylist status; then
        magisk --denylist rm com.google.android.gms
        magisk --denylist rm com.android.vending
    fi
    
    . $MODPATH/common_setup.sh
else

    magisk --denylist add com.google.android.gms com.google.android.gms.unstable
    magisk --denylist add com.android.vending
fi


resetprop_if_diff ro.boot.warranty_bit 0
resetprop_if_diff ro.vendor.boot.warranty_bit 0
resetprop_if_diff ro.vendor.warranty_bit 0
resetprop_if_diff ro.warranty_bit 0

resetprop_if_diff ro.boot.realmebootstate green

resetprop_if_diff ro.is_ever_orange 0

for PROP in $(resetprop | grep -oE 'ro.*.build.tags'); do
    resetprop_if_diff $PROP release-keys
done

for PROP in $(resetprop | grep -oE 'ro.*.build.type'); do
    resetprop_if_diff $PROP user
done
resetprop_if_diff ro.adb.secure 1
if ! $SKIPDELPROP; then
    delprop_if_exist ro.boot.verifiedbooterror
    delprop_if_exist ro.boot.verifyerrorpart
fi
resetprop_if_diff ro.boot.veritymode.managed yes
resetprop_if_diff ro.debuggable 0
resetprop_if_diff ro.force.debuggable 0
resetprop_if_diff ro.secure 1
